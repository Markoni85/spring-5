package io.javabrains.springdatajpanm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringDataJpaNmApplicationTests {

	@Test
	void contextLoads() {
	}

}
