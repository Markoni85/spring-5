package io.javabrains.springdatajpanm.repository;

import org.springframework.data.repository.CrudRepository;

import io.javabrains.springdatajpanm.model.Course;

public interface CourseRepository extends CrudRepository<Course, Integer>{

}
