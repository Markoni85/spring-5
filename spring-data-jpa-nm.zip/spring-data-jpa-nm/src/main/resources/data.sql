
INSERT INTO course (name) VALUES ('Spring Boot');
INSERT INTO course (name) VALUES ('.Net core');
INSERT INTO course (name) VALUES ('Java Script');